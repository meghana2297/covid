import React, { Component } from 'react';
import Home from './components/home'
import Charts from './components/Charts'
import Country from './components/Country'
import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

class App extends Component {
   
    render() {
        return (
            <Router>
                <div  >
                    <Switch>

                        <Route exact path="/" component={Home} />
                        <Route exact path="/charts" component={Charts} />
                        <Route exact path="/country" component={Country} />

                    </Switch>
                </div>
            </Router>
        );
    }
}
export default App;
