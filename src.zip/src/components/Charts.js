import React, { Component } from 'react';
import Navbar from './Navbar';
import { Container} from 'react-bootstrap';
import { CountryDropdown } from 'react-country-region-selector';
import images from '../images/covid19.png';
import '../App.css'
import { Bar } from 'react-chartjs-2';
import axios from 'axios';
const divStyle = {
    position: "absolute",
    marginTop: "8%",
    width: '106.5%',
    height: '500px',
    backgroundImage: `url(${images})`,
    backgroundSize: 'cover'
};

class Charts extends Component {
   
    constructor(props) {
        super(props);
        this.url = 'https://covid19.mathdro.id/api'
        this.state = {
            data: {},
            country: '',
           region:'',
            confirmed: '',
            deaths: '',
            recovered: '',
            flag: false,
            countryFlag: false
           
        };
    }



    componentDidMount() {
        console.log(this.url)
        axios.get(this.url)
            .then(res => {
                console.log(res.data)

                this.setState({
                    data: {
                        labels: ['Confirmed', 'Deaths', 'Recovered'],
                        datasets: [
                                    {
                                label: "World wide cases",

                                backgroundColor: ['rgba(3,57,108)', 'rgba(100,151,177)', 'rgba(179,205,224)'],
                                        borderColor: 'rgba(118, 158, 203,1)',
                                        borderWidth: 1,
                                        hoverBackgroundColor: 'rgba(118, 158, 203,0.4)',
                                        hoverBorderColor: 'rgba(118, 158, 203,1)',
                                data: [res.data.confirmed.value, res.data.deaths.value, res.data.recovered.value]
                                    }
                                 ]

                        }
                })
            })
        }
       
   
    selectCountry(val) {

        this.setState({ country: val });
        axios.get(`https://covid19.mathdro.id/api` + '/countries/' + val)
            .then(res => {
                console.log(val)
                console.log(res.data)
                this.setState({
                    data: {
                        labels: ['Confirmed', 'Deaths', 'Recovered'],
                        datasets: [
                            {
                                label: "World wide cases",

                                backgroundColor: ['rgba(3,57,108)', 'rgba(100,151,177)', 'rgba(179,205,224)'],
                                borderColor: 'rgba(118, 158, 203,1)',
                                borderWidth: 1,
                                hoverBackgroundColor: 'rgba(118, 158, 203,0.4)',
                                hoverBorderColor: 'rgba(118, 158, 203,1)',
                                data: [res.data.confirmed.value, res.data.deaths.value, res.data.recovered.value]
                            }
                        ]

                    }
                })

                
            })
        
    }

    render() {
        const { country } = this.state;
        return (
            <div>
                <Navbar />

                <Container style={{ width: "100%", position: "absolute" }}>
                    <div className="App" style={divStyle}>
                        <br />
                        <div className="chartmodel">
                            <div className="countrymodel">
                                <div>
                                    <CountryDropdown style={{ width: "20%", border: "1px solid white", borderRadius: "4px", left: "2%", position: "absolute", top: "5%" }}
                                        value={country}
                                        onChange={(val) => this.selectCountry(val)}
                                    />&nbsp;&nbsp;
                                                   </div>
                            <Bar data={this.state.data}
                                width={45}
                                height={13}
                                 />
                        </div>
                        </div>
                        </div>
                </Container>
            </div>
        );
    }
}

export default Charts;
