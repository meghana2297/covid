import React, { Component } from 'react';
import Typography from '@material-ui/core/Typography';
import { Container } from 'react-bootstrap';
import images from '../images/covid19.png';
import '../App.css'
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import axios from 'axios';
const divStyle = {
    position: "absolute",
    marginTop: "8%",
    width: '106.5%',
    height: '500px',
    backgroundImage: `url(${images})`,
    backgroundSize: 'cover'
};
class Content extends Component {

    constructor(props) {
        super(props);
        this.state = {
            confirmed: "",
            death: "",
            recovered: ""
        }


    }
    componentDidMount() {
        axios.get(`https://covid19.mathdro.id/api`)
            .then(res => {
                this.setState({ confirmed: res.data.confirmed.value, death: res.data.deaths.value, recovered: res.data.recovered.value })

            })
           }
    

    render() {
       
        return (
           
            <div>
               
                <Container style={{ width: "100%", position: "absolute" }}>
                    <div className="App" style={divStyle}>
                        <br />
                        <div className="model">
                            <Card style={{ position: "absolute", width: "40%", height: "27%", left: "30%", top: "5%" }} >
                                <CardContent>
                                    <Typography gutterBottom variant="h5" component="h2">
                                        <h3 style={{ color: "orange" }}>{this.state.confirmed}</h3>
                                        <p style={{ position: "absolute", top: "50%", fontSize: "80%" }}>Confirmed</p>
                                    </Typography>
                                </CardContent>
                            </Card>
                            <Card className="shadow" style={{ position: "absolute", width: "40%", height: "27%", left: "30%", top: "37%" }} >
                                <CardContent>
                                    <Typography gutterBottom variant="h5" component="h2">
                                        <h3 style={{ color: "red" }}>{this.state.death}</h3>
                                        <p style={{ position: "absolute", top: "50%", fontSize: "80%" }}>Deaths</p>
                                    </Typography>
                                </CardContent>
                            </Card>
                            <Card className="shadow" style={{ position: "absolute", width: "40%", height: "27%", left: "30%", top: "70%" }} >
                                <CardContent>
                                    <Typography gutterBottom variant="h5" component="h2">
                                        <h3 style={{ color: "green" }}>{this.state.recovered}</h3>
                                        <p style={{ position: "absolute", top: "50%", fontSize: "80%" }}>Recovered</p>
                                    </Typography>
                                </CardContent>
                            </Card>
                        </div>
                    </div>
                </Container>
            </div>
        );
    }
}

export default Content;
