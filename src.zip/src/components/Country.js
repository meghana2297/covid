import React, { Component } from 'react';
import Navbar from './Navbar';
import { Container ,Row} from 'react-bootstrap';
import Typography from '@material-ui/core/Typography';
import { CountryDropdown, RegionDropdown } from 'react-country-region-selector';
import images from '../images/covid19.png';
import '../App.css'
import Card from '@material-ui/core/Card';

import CardContent from '@material-ui/core/CardContent';

import axios from 'axios';
const divStyle = {
    position: "absolute",
    marginTop: "8%",
    width: '106.5%',
    height: '500px',
    backgroundImage: `url(${images})`,
    backgroundSize: 'cover'
};
class Charts extends Component {
    constructor(props) {
        super(props);
        this.state = {
            country: '',
            region: '',
            flag: false,
            confirmed: "",
            death: "",
            recovered: "" };
    }

    selectCountry(val) {
        
        this.setState({ country: val });
    }

    selectRegion(val) {
        this.setState({ region: val,flag:true });
    }
    componentDidUpdate() {
       
        if (this.state.flag === false) {
            var value = this.state.country
            axios.get(`https://covid19.mathdro.id/api` + '/countries/' + value)
                .then(res => {
                    this.setState({ confirmed: res.data.confirmed.value, death: res.data.deaths.value, recovered: res.data.recovered.value })
                })
        }
        else {
            var value = this.state.country
            var region = this.state.region
            axios.get(`https://covid19.mathdro.id/api` + '/countries/' + value +'/confirmed')
                .then(res => {
                   res.data.map((value) => {
                      
                       if (value.provinceState == this.state.region) {
                           
                           this.setState({ confirmed: value.confirmed, death: value.deaths, recovered: value.recovered })
                       }

                    })
                    

                })

        }
       
    }
    handleclick = () => {
        this.setState({flag:false,region:""})
    }

     render() {
         const { country, region } = this.state;
        return (
            <div>
                <Navbar/>
                <Container style={{ width: "100%", position: "absolute" }}>
                    <div className="App" style={divStyle}>
                        <div className="countrymodel">
                            <div>
                                <CountryDropdown style={{ width: "20%", border: "1px solid white", borderRadius: "4px", left: "2%", position: "absolute", top: "5%" }}
                                    value={country}
                                    onChange={(val) => this.selectCountry(val)}
                                   

                                />&nbsp;&nbsp;
                                <RegionDropdown style={{ width: "20%", border: "1px solid white", borderRadius: "4px", left: "23%", position: "absolute", top: "5%" }}
                                    country={country}
                                    value={region}
                                    onChange={(val) => this.selectRegion(val)}
                                    defaultOptionLabel="Select region"
                                    blankOptionLabel="Select region"
                                    onBlur={this.handleclick}
                                />
                                
                            </div>
                            <Row>
                                <Card style={{ position: "absolute", width: "25%", height: "27%", left: "3%", top: "30%" }} >
                                    <CardContent>
                                        <Typography gutterBottom variant="h5" component="h2">
                                            <h3 style={{ color: "orange" }}>{this.state.confirmed}</h3>
                                            <p style={{ position: "absolute", top: "50%", fontSize: "80%" }}>Confirmed</p>
                                        </Typography>
                                    </CardContent>
                                </Card>
                                <Card style={{ position: "absolute", width: "25%", height: "27%", left: "36%", top: "30%" }} >
                                    <CardContent>
                                        <Typography gutterBottom variant="h5" component="h2">
                                            <h3 style={{ color: "red" }}>{this.state.death}</h3>
                                            <p style={{ position: "absolute", top: "50%", fontSize: "80%" }}>Deaths</p>
                                        </Typography>
                                    </CardContent>
                                </Card>
                                <Card style={{ position: "absolute", width: "25%", height: "27%", left: "70%", top: "30%" }} >
                                    <CardContent>
                                        <Typography gutterBottom variant="h5" component="h2">
                                            <h3 style={{ color: "green" }}>{this.state.recovered}</h3>
                                            <p style={{ position: "absolute", top: "50%", fontSize: "80%" }}>Recovered</p>
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Row>
                        </div>
                    </div>
                </Container>
            </div>
        );
    }
}

export default Charts;
