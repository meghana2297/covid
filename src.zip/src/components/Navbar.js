import React, { Component } from 'react';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import { Container } from 'react-bootstrap';
import { withRouter } from "react-router-dom";
import '../App.css'


class Navbar extends Component {

    handleChartsclick = () => {
            this.props.history.push({
            pathname: '/charts'
        })
    }
    handleworldclick = () => {
        this.props.history.push({
            pathname: '/'
        })
    }
    handlecountryclick = () => {
        this.props.history.push({
            pathname: '/country'
        })
    }
    render() {
        
        return (

            <div>
                <Container style={{ width: "100%", position: "absolute" }}>
                    <AppBar position="static" style={{ margin: "0", width: "106.5%", position: "absolute" }}>
                        <Toolbar>
                            <IconButton edge="start" color="inherit" aria-label="menu">
                            </IconButton>

                            <Typography variant="h6" >
                                <Button color="inherit" onClick={this.handleworldclick}><h1>COVID-19</h1></Button>
                            </Typography>

                            <Typography variant="h6" >
                                <Button style={{ position: "absolute", left: "45%", top: "15%" }} color="inherit" onClick={this.handleChartsclick}><h5>Charts</h5></Button>
                            </Typography>

                            <Typography variant="h6" >
                                <Button style={{ position: "absolute", left: "55%", top: "15%" }} color="inherit" onClick={this.handleworldclick}><h5>Worldwide</h5></Button>
                            </Typography>

                            <Typography variant="h6" >
                                <Button style={{ position: "absolute", left: "70%", top: "15%" }} color="inherit" onClick={this.handlecountryclick}><h5>See country wise</h5></Button>
                            </Typography>
                            
                        </Toolbar>
                    </AppBar>
                    
                </Container>
            </div>
        );
    }
}

export default withRouter(Navbar);
